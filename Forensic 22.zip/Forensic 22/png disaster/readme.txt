Aku Baru Aja Membuat Design Yang Mungkin Kamu Cari, Namun Aku Tidak Mau Kamu Mengetahuinya Aku Mengubah bitbit Agar Kamu Tidak Bisa Membuka File Ini

Hint = head