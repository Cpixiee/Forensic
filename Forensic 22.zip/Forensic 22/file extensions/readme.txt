Kamu Tau File Extensions???

Hint = Cobalah Strings file untuk menemukan hintnya